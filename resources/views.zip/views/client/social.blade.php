<div class="footer_social">
                    <a href="https://www.facebook.com/electroAzerbaijan/?__tn__=%2Cd%2CP-R&eid=ARD7osn7CyJFfyBDAmWb2FrY9SJaqi3F0iJ5Szyq6T4RNCOw45lFyZo5mGSSb8_ktJg1is_7lKegtjb0">
                        <svg class="icon icon-fb soc_ico lazyload blur_up">
                            <use xlink:href="{{ asset('./images/sprite/sprite.svg#fb') }}"></use>
                        </svg>
                    </a>
                    <a href="https://www.instagram.com/electro.az_/">
                        <svg class="icon icon-in soc_ico lazyload blur_up">
                            <use xlink:href="{{ asset('./images/sprite/sprite.svg#in') }}"></use>
                        </svg>
                    </a>
                    <a href="https://www.youtube.com/channel/UCnloW1SPyWY3ApZPikJX0oQ">
                        <svg class="icon icon-yt soc_ico lazyload blur_up">
                            <use xlink:href="{{ asset('./images/sprite/sprite.svg#yt') }}"></use>
                        </svg>
                    </a>
                </div>