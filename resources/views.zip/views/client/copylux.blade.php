<div class="footer_copyright">
    <p class="text">© 2019 LuxHome </p>
</div>