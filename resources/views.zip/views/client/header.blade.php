
  <header class="header">
      <div class="container">
        <div class="row row_align_center row_justify_between">
           <!-- LOGO --><a class="logo_box" href="/">
                <svg class="icon icon-logo logo_ico lazyload blur_up">
                  <use xlink:href="{{ asset('./images/sprite/sprite.svg#logo') }}"></use>
                </svg></a>
          <!-- END LOGO -->
          <!-- SEARCH-->
          <form class="search_box" action="{{ route('search') }}">
          <input type="search" name="search_field" placeholder="Axtarış..." minlength="3" value="{{ request()->search_field}}">
            <button type="submit">
                  <svg class="icon icon-search search_ico lazyload blur_up">
                    <use xlink:href="{{ asset('./images/sprite/sprite.svg#search') }}"></use>
                  </svg>
            </button>
            <div  class="search_box_result">
                 <a class="search_box_result_row" href="#"><img  src="" class="lazyload blur_up" alt=""><!-- <img class="lazyload blur_up" src="images/main/index/" alt="Search products category images"> --> <h4 class="h4"></h4></a>
                    <a class="search_box_result_row" href="#"><h4 class="h4">Seen all</h4></a>
                  </div>
          </form>
          <!-- END SEARCH -->
          <!-- NAVIGATION-->
          <nav class="main_nav_menu">
            <!-- MAIN MENU -->
            @include('client.nav')
            <!-- END MAIN MENU-->
            <!-- CALLBACK NUMBER-->
            <!-- END CALLBACK NUMBER -->
            <!-- MOBILE SEARCH-->
            <form class="search_mobile" action="{{ route('search')}}" >
                <input type="text"  name="search_field"   minlength="3" value="{{ request()->search_field}}" placeholder="Axtarış...">
                <button type="submit">
                      <svg class="icon icon-search search_ico lazyload blur_up">
                        <use xlink:href="{{ asset('./images/sprite/sprite.svg#search') }}"></use>
                      </svg>
                </button>
                <div class="search_box_result">
                    <a class="search_box_result_row" href="#"><img  src="" class="lazyload blur_up" alt=""><!-- <img class="lazyload blur_up" src="images/main/index/item.img" alt="Search products category images"> --> <h4 class="h4"></h4></a>
                      <a class="search_box_result_row" href="#"><h4 class="h4">Seen all</h4></a>
                    </div>
              </form>
            <!-- END SEARCH -->
          </nav>
          <!-- END NAVIGATION-->
          <!-- USER INTERFACE BTN-->
          <div class="user_interface">
          <a class="callback_link" href="tel: *0666">
                  <svg class="icon icon-call tel_ico lazyload blur_up">
                    <use xlink:href="./images/sprite/sprite.svg#call"></use>
                  </svg>*0666</a>
            <div class="lang_box">
              <select name="lang" onchange="alert('Digər dillərdə hələ mövcud deyil')">
                <option value="az">az</option>
                <option value="ru">ru</option>
                <option value="en">en</option>
              </select>
            </div>
            <div class="menu_hamburger"> <a href="#">
                    <svg class="icon icon-menu map_ico lazyload blur_up">
                      <use xlink:href="{{ asset('./images/sprite/sprite.svg#menu') }}"></use>
                    </svg></a></div>
            <div class="search_box_btn"><a href="#">
                    <svg class="icon icon-search map_ico lazyload blur_up">
                      <use xlink:href="{{ asset('./images/sprite/sprite.svg#search') }}"></use>
                    </svg></a></div>
          </div>
          <!-- END USER INTERFACE BTN-->
        </div>
      </div>
    </header>
