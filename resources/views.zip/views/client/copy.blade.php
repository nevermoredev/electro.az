<div class="footer_copyright">
    <p class="text">© 2020 electro.az </p>
</div>
