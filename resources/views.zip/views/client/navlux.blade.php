<ul class="lux-nav-ul">		
				<li><a id="lux-nav" href="{{ route('luxhomeMain') }}">Məssular</a></li>	
              <li ><a id="lux-nav" href="{{ route('aboutLux') }}">Haqqımızda</a></li>
              <li><a id="lux-nav" href="{{ route('filialLux') }}">Filiallar</a></li>
              <li><a id="lux-nav" href="{{ route('mainClient') }}">{{-- alt="Electro az category menu" --}}<span class="next-side">Electron mallar</span></a>
              {{-- class="active_menu_items" --}}
</ul>

