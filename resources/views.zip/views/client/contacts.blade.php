<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{-- {{ $title }} --}}Tezliklə...</title>
    <meta content="" name="webskyus">
    <meta content="" name="this is description">
    <meta content="" name="website, landing">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta content="ie=edge" http-equiv="x-ua-compatible">
     @include('favicon')
    <link rel="apple-touch-icon" href="{{ asset('./images/main/favicon/apple-icon-180x180.png') }}">
    <link rel="stylesheet" href="{{ asset('style/main.min.css') }}">
    <link rel="stylesheet" href="{{ asset('styles/main/panel.css') }}">
</head>

<body>
{{--     @include('client.header')--}}
    <main class="main">
        <!-- SECTION SECTION Contacts-->
        <section class="contacts">
            <div class="container">
                <div class="row row_justify_center">
                    <div class="contacts_wrap">
                        <div class="row">
                            @foreach ($collection as $item)
                            <div class="contacts_col">
                            <h2 class="contacts_title">Filial {{$item->filial}}</h2>
                                <h3 class="contacts_subtitle">
                                    Ünvan: {{$item->address}} |
                                    <a href="tel: +994512554451">Əlagə nömrəsi: {{$item->number}}</a>
                                </h3>
                                <div class="contacts_map_wrap">
                                   {!!$item->iframe!!}
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END SECTION Contacts-->
    </main>
    <!-- FOOTER-->
{{--    <footer class="footer">--}}
{{--        <div class="container">--}}
{{--            <div class="row row_align_center">--}}
{{--                @include('client.social')--}}
{{--                @include('client.copy')--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </footer>--}}
    <!-- END FOOTER-->
    <script src="{{ asset('js/scripts.min.js') }}" defer></script>
    <script src="{{ asset('js/main.min.js') }}" defer></script>
    <script src="{{ asset('js/maps.js') }}" defer></script>
</body>

</html>
