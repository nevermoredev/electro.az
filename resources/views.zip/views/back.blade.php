
    <a onclick="goBack()" ><button class="btn-info">Qayit</button></a>
    <script>
        function goBack() {
          window.history.back(2);
        }
    </script>
    