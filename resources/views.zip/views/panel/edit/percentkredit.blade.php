@extends('main-panel')

@section('header')
@endsection
@section('content')
    <div class="container">
        @include('back')
        <div class="form-add">
            <h3>Yeni kredit şablonu</h3>
            <form action="{{ route('edit-percentkredit',['id'=>$collection->id]) }}" method="post" enctype="multipart/form-data">
                {{ csrf_field() }}
                <div class="form-group">
                    <div class="container">
                        <div class="input-add">
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Adı</label>
                                <input name="name"  value="{{$collection->name}}" placeholder="Adı" type="text" class="form-control" id="" aria-describedby="" >
                            </div>
                        </div>
                        @for($i = 2 ;$i < 37 ;$i++)
                            @php
                            $key = 'ay_'.$i;
                            @endphp
                            <div class="input-add">
                                <div class="form-group">
                                    <label for="exampleFormControlTextarea1">{{$i.' - ay'}}</label>
                                    <input name="{{$key}}"  value="{{$collection->$key}}"  placeholder="Faiz" type="number" class="form-control" id="" aria-describedby="" >
                                </div>
                            </div>
                        @endfor
                    </div>

                <button type="submit" class="btn btn-primary mb-2">Dəyişdir</button>
        </div>
        </form>
    </div>
    </div>
@endsection

@section('footer')

@endsection
