@extends('main-panel')

@section('header')
    <div class="botom-head">
      <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="nav nav-tabs noborder">
            <li class="nav-item">
            <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Audio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Audio Audio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="product-view-style" href="{{ route('viewaudio') }}">Link</a>
            </li>
          </ul>  
        </div>
      </nav>
</div>
@endsection
@section('content')
@endsection

@section('footer')
    
@endsection